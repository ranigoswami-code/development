//Question 1: Defining and Calling a Function
// Create a JavaScript program that demonstrates how to define
// and call a function.
// Your program should:
// • Define a function named showWelcome().
// • Display a welcome message inside the function using
// console.log().
// • Call the function to execute its code.
// • Call the same function multiple times to demonstrate
// code reusability.
// • Display the results using console.log()

function showWelcome() {
    console.log("Welcome to java script funtion class");
}

showWelcome();
showWelcome();
showWelcome();

// Question 2: Function Execution Flow
// Create a JavaScript program that demonstrates the execution
// flow of a function.
// Your program should:
// • Define a function named showMessage() that displays
// "Learning JavaScript Functions".
// • Display "Start" before calling the function.
// • Call showMessage().
// • Display "End" after the function call.
// • Call the function again at another point in the program.
// • Use console.log() to clearly observe the order in which
// the statements execute.

function showMessage() {

    console.log("Learning JavaScript Functions");

}
console.log("start");
showMessage();
console.log("End");
showMessage();